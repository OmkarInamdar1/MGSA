import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;

public class BrowserCommandsEdge {

    public static void main(String[] args) {

        System.setProperty("webdriver.Edge.driver", "C:\\Users\\renukaDS\\Downloads\\edgedriver_win64\\msedgedriver.exe");
        WebDriver driver = new EdgeDriver();
        driver.get("https://www.facebook.com/login/");

        driver.manage().window().maximize();

        String title = driver.getTitle();
        System.out.println(title);

        String currentURL = driver.getCurrentUrl();
        System.out.println(currentURL);

        String pagesource = driver.getPageSource();
        System.out.println(pagesource);

        driver.close();

    }
}
