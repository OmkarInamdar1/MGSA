import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;

public class NavigationalCommands {

    public static void main(String[] args) {

        System.setProperty("webdriver.Edge.driver", "C:\\Users\\renukaDS\\Downloads\\edgedriver_win64\\msedgedriver.exe");
        WebDriver driver = new EdgeDriver();

        driver.manage().window().maximize();

        //navigate to URL
        driver.navigate().to("https://www.facebook.com/login/");

        //navigate backward in browser
        driver.navigate().back();

        //refresh page
        driver.navigate().refresh();

        //navigate forwards in browser history
        driver.navigate().forward();

    }
}
