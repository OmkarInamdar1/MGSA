import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class BrowserCommands {

    public static void main(String[] args) {

        System.setProperty("webdriver.chrome.driver", "C:\\Users\\renukaDS\\Downloads\\chromedriver_win32\\chromedriver.exe");
        WebDriver driver = new ChromeDriver();
        driver.get("https://www.facebook.com/login/");

        //maximize the window
        driver.manage().window().maximize();

        String title = driver.getTitle();
        System.out.println(title);

        String currentURL = driver.getCurrentUrl();
        System.out.println(currentURL);

        String pagesource = driver.getPageSource();
        System.out.println(pagesource);

        driver.close();
    }
}
