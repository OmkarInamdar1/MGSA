import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class AutomateText {

    public static void main(String[] args) {

        System.setProperty("webdriver.chrome.driver", "C:\\Users\\renukaDS\\Downloads\\chromedriver_win32\\chromedriver.exe");
        WebDriver driver = new ChromeDriver();
        driver.get("https://demo.guru99.com/test/newtours/register.php");


        driver.manage().window().maximize();

        WebElement FirstName = driver.findElement(By.xpath("//tbody/tr[2]/td[2]/input[1]"));
        FirstName.sendKeys("OMKAR");

        WebElement LastName = driver.findElement(By.xpath("//tbody/tr[3]/td[2]/input[1]"));
        LastName.sendKeys("INAMDAR");

        WebElement Phone = driver.findElement(By.xpath("//tbody/tr[4]/td[2]/input[1]"));
        Phone.sendKeys("7338117752");

        WebElement Email = driver.findElement(By.xpath("//input[@id='userName']"));
        Email.sendKeys("omkarpurushottam777@gmail.com");

        WebElement Address = driver.findElement(By.xpath("//tbody/tr[7]/td[2]/input[1]"));
        Address.sendKeys("BANGALORE");

        WebElement City = driver.findElement(By.xpath("//tbody/tr[8]/td[2]/input[1]"));
        City.sendKeys("KALABURAGI");

        WebElement State = driver.findElement(By.xpath("//tbody/tr[9]/td[2]/input[1]"));
        State.sendKeys("KARNATAKA");

        WebElement PostalCode = driver.findElement(By.xpath("//tbody/tr[10]/td[2]/input[1]"));
        PostalCode.sendKeys("585302");

        WebElement Username = driver.findElement(By.xpath("//input[@id='email']"));
        Username.sendKeys("omkarpurushottam777@gmail.com");

        WebElement password = driver.findElement(By.xpath("//tbody/tr[14]/td[2]/input[1]"));
        password.sendKeys("1234567");

        WebElement RePassword = driver.findElement(By.xpath("//tbody/tr[15]/td[2]/input[1]"));
        RePassword.sendKeys("1234567");





    }
}
